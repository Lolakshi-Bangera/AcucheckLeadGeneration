__turbopack_load_page_chunks__("/Footer", [
  "static/chunks/b79f98ef3f664a44.js",
  "static/chunks/305318cf9c1203ba.js",
  "static/chunks/5c1fdae0393c144c.js",
  "static/chunks/33996de8dd6d1c7e.js",
  "static/chunks/d41522dc24f47b67.js",
  "static/chunks/7caef8a25b5c9f28.js",
  "static/chunks/turbopack-f0dec591236b7a4b.js"
])
