__turbopack_load_page_chunks__("/under-renovation", [
  "static/chunks/1db53ee4e00758d8.js",
  "static/chunks/305318cf9c1203ba.js",
  "static/chunks/cd6eb1e5328897e6.js",
  "static/chunks/d41522dc24f47b67.js",
  "static/chunks/33996de8dd6d1c7e.js",
  "static/chunks/7caef8a25b5c9f28.js",
  "static/chunks/6a0d788f58d06b45.js",
  "static/chunks/ef6513bafae4096e.css",
  "static/chunks/turbopack-0ad3f19d39318cbb.js"
])
