(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/46926_7af73986._.js",
  "static/chunks/acuview-lead_src_Components_Header_tsx_95e55d3c._.js"
],
    source: "dynamic"
});
