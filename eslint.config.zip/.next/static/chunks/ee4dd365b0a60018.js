__turbopack_load_page_chunks__("/WhyAcuView", [
  "static/chunks/b94dbec8a9cbf13d.js",
  "static/chunks/6a0d788f58d06b45.js",
  "static/chunks/d41522dc24f47b67.js",
  "static/chunks/305318cf9c1203ba.js",
  "static/chunks/turbopack-f8f1840d8b549d91.js"
])
