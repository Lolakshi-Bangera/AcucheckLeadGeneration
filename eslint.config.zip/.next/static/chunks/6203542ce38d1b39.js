__turbopack_load_page_chunks__("/_app", [
  "static/chunks/d005e857000a9dbf.js",
  "static/chunks/d41522dc24f47b67.js",
  "static/chunks/305318cf9c1203ba.js",
  "static/chunks/turbopack-53726b690409430b.js"
])
