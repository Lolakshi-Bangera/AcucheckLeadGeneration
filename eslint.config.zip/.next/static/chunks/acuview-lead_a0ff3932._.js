(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_49c01ce6._.js",
  "static/chunks/46926_next_dist_compiled_react-dom_9bea2c6e._.js",
  "static/chunks/46926_next_dist_compiled_next-devtools_index_1cd9c962.js",
  "static/chunks/46926_next_dist_compiled_779f559e._.js",
  "static/chunks/46926_next_dist_client_87fdf61d._.js",
  "static/chunks/46926_next_dist_eb6735ab._.js",
  "static/chunks/46926_@swc_helpers_cjs_75541771._.js"
],
    source: "entry"
});
