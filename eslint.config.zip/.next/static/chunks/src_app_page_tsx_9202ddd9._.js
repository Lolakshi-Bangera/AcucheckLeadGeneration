(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_Components_32c1ace4._.js",
  "static/chunks/node_modules_next_b5461c77._.js",
  "static/chunks/node_modules_react-icons_ri_index_mjs_150b4c77._.js",
  "static/chunks/node_modules_react-icons_lib_844c6c50._.js",
  "static/chunks/node_modules_moment_87c24e78._.js",
  "static/chunks/node_modules_moment-timezone_c3000de4._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_a97d269f._.js"
],
    source: "dynamic"
});
