(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_8df24b7a._.js",
  "static/chunks/c06a0_next_dist_compiled_react-dom_835169bd._.js",
  "static/chunks/c06a0_next_dist_compiled_next-devtools_index_96857f1e.js",
  "static/chunks/c06a0_next_dist_compiled_ea255378._.js",
  "static/chunks/c06a0_next_dist_client_4d7bb37a._.js",
  "static/chunks/c06a0_next_dist_a5d2dcbe._.js",
  "static/chunks/c06a0_@swc_helpers_cjs_9caa3d9c._.js"
],
    source: "entry"
});
