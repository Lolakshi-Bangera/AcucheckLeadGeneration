__turbopack_load_page_chunks__("/DemoBanner", [
  "static/chunks/907f7e5249acc476.js",
  "static/chunks/cd6eb1e5328897e6.js",
  "static/chunks/305318cf9c1203ba.js",
  "static/chunks/d41522dc24f47b67.js",
  "static/chunks/ef6513bafae4096e.css",
  "static/chunks/turbopack-0a79bee1a04951da.js"
])
