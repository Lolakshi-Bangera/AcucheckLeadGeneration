__turbopack_load_page_chunks__("/StatsSection", [
  "static/chunks/daeda6c771ef962e.js",
  "static/chunks/d41522dc24f47b67.js",
  "static/chunks/305318cf9c1203ba.js",
  "static/chunks/turbopack-4af699bcd071abb4.js"
])
