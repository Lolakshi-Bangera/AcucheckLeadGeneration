(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/c06a0_0615d981._.js",
  "static/chunks/Acuview-Lead-Generation_src_Components_Header_tsx_c6bdecb6._.js"
],
    source: "dynamic"
});
