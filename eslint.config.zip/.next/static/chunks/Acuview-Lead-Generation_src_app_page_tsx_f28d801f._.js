(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Acuview-Lead-Generation_src_Components_7a44ff3c._.js",
  "static/chunks/c06a0_next_70d9c30c._.js",
  "static/chunks/c06a0_react-icons_ri_index_mjs_09aaf53f._.js",
  "static/chunks/c06a0_react-icons_fa_index_mjs_d43d4a89._.js",
  "static/chunks/c06a0_react-icons_lib_6fdde31c._.js",
  "static/chunks/c06a0_moment_41b4c4f0._.js",
  "static/chunks/c06a0_moment-timezone_0930d770._.js",
  "static/chunks/c06a0_lucide-react_dist_esm_40761008._.js"
],
    source: "dynamic"
});
