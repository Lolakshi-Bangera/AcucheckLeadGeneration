__turbopack_load_page_chunks__("/WhyChooseAcuView", [
  "static/chunks/53b738da46ed6b7a.js",
  "static/chunks/cd6eb1e5328897e6.js",
  "static/chunks/305318cf9c1203ba.js",
  "static/chunks/d41522dc24f47b67.js",
  "static/chunks/turbopack-5314c10af229235d.js"
])
