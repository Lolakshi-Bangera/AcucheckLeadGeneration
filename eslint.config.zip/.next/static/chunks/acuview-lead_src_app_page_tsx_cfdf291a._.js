(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/acuview-lead_src_Components_1ce2e9d5._.js",
  "static/chunks/46926_next_b0b52bf0._.js",
  "static/chunks/46926_react-icons_ri_index_mjs_25d6511a._.js",
  "static/chunks/46926_react-icons_fa_index_mjs_8cf7d90a._.js",
  "static/chunks/46926_react-icons_lib_b19dd9be._.js",
  "static/chunks/46926_moment_e2443c8b._.js",
  "static/chunks/46926_moment-timezone_eb9320c7._.js",
  "static/chunks/46926_lucide-react_dist_esm_c3561cc4._.js"
],
    source: "dynamic"
});
