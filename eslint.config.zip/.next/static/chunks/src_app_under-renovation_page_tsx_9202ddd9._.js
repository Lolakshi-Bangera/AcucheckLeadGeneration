(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_aefbe0bc._.js",
  "static/chunks/src_Components_Header_tsx_35a01061._.js"
],
    source: "dynamic"
});
