__turbopack_load_page_chunks__("/_error", [
  "static/chunks/1e8f8de5a387974c.js",
  "static/chunks/d41522dc24f47b67.js",
  "static/chunks/305318cf9c1203ba.js",
  "static/chunks/turbopack-25d055ae9f149300.js"
])
